<?php $__env->startSection('titulo','estudiantes'); ?>

<?php $__env->startSection('contenido'); ?>
    <br>
    <h3>Nuevos Estudiantes</h3>
    <form action="/estudiantes" method="post">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
          <label for="nombre" class="form-label">Nombre y Apellido</label>
          <input type="text" class="form-control" id="nombre" name="nombre">
        </div>
        <div class="mb-3">
            <label for="interes" class="form-label">interes</label>
            <input type="text" class="form-control" id="interes" name="interes">
        </div>
        <button type="submit" class="btn btn-success">Guardar</button>
    </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\YURI\Desktop\SENA SOFIA YURI V\GA7\laravel\laravel_yuri_artunduaga\resources\views/estudiantes/create.blade.php ENDPATH**/ ?>